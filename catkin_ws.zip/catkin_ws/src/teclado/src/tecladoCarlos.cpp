/*********************************************************************** 
 * Derechos reservados                                                 *
 * Autores: Leticia Oyuki Rojas Perez, Jose Martinez Carranza          * 
 * Versión: 1.0                                                        *
 * Última actualización:  05/06/2018                                   *
 * Curso CADI 2018                                                     *  
 *                                                                     *
 * Ejemplo de Interfaz de control manual                               *
 *                                                                     *     
 ***********************************************************************/
 
#include <QKeyEvent>
#include "teclado.h"
#include <chrono>
#include <thread>

static void trajectoryPlanner(int a);
static void hover();
static void land();
static void takeOff();
static void pitch(int speed);
static void yaw(int speed);
static void upDown(int speed);
static void pitchYaw(int speedP, int speedY);


KeyPress::KeyPress(QWidget *parent): 
		nh_("~"), QWidget(parent)
{
	ROS_INFO("Init Keyboard Controller");
	
//	pubTakeoff1_ = nh_.advertise<std_msgs::Empty>("/ardrone/takeoff", 3);
//	pubLand1_ = nh_.advertise<std_msgs::Empty>("/ardrone/land", 3);
//	pubCommandPilot1_ = nh_.advertise<geometry_msgs::Twist>("/cmd_vel", 3);
	
	pubTakeoff1_ = nh_.advertise<std_msgs::Empty>("/bebop/takeoff", 3);
	pubLand1_ = nh_.advertise<std_msgs::Empty>("/bebop/land", 3);
	pubCommandPilot1_ = nh_.advertise<geometry_msgs::Twist>("/bebop/cmd_vel", 3);

//	pubCommandCamera1_ = nh_.advertise<geometry_msgs::Twist>("/bebop/camera_control", 3);
	
	OvR = nh_.advertise<std_msgs::Int8>("/keyboard/override", 3);
	
	speed = 0.3;
	altitude_speed = 1.0;
	pitch = 0;
	roll = 0;
	yaw = 0;
	altitude = 0;
	fovea_y = 0;
	
	override.data = 0;

	Speed = new QLabel("Pitch", this);
	Alt_speed = new QLabel("Roll", this);
	Fovea_y = new QLabel("Fovea", this);
	
	Speed_value = new QLabel("0", this);
	Alt_speed_value = new QLabel("0", this);
	Fovea_value_y = new QLabel("  0", this);
	Command = new QLabel(" ", this);

	font= Command->font();
	font.setPointSize(20);
	font.setBold(true);
	Command->setFont(font);
	
	
	
    Speed->setText("Speed:");
    Alt_speed->setText("Altitude Speed:");
	Fovea_y->setText("Fovea Y:");
	
	grid = new QGridLayout(this);
	
	grid->addWidget(Speed, 1, 0);
	grid->addWidget(Alt_speed, 2, 0);
	grid->addWidget(Fovea_y, 4, 0);
		
	grid->addWidget(Speed_value, 1 ,1);
	grid->addWidget(Alt_speed_value, 2, 1);
	grid->addWidget(Fovea_value_y, 4, 1);
	grid->addWidget(Command, 5, 0);

    Speed_value->setText(QString::number(speed));
    Alt_speed_value->setText(QString::number(altitude_speed));

    setLayout(grid);
}

KeyPress::~KeyPress()
{

}

void KeyPress::keyPressEvent(QKeyEvent *event) 
{   
    //agregar al main
    using namespace std::this_thread; // sleep_for, sleep_until
    using namespace std::chrono; // nanoseconds, system_clock, seconds


	bool send_command = true;

	commandPilot.linear.x = 0.0;
	commandPilot.linear.y =  0.0;
	commandPilot.linear.z = 0.0;
	commandPilot.angular.z = 0.0;
	
	pitch = 0;
	roll = 0;
	altitude = 0;
	yaw = 0;

	if(event->key() == Qt::Key_H)
	{	
		pitch = 0.0;
		roll = 0.0;
		altitude = 0.0;
		yaw = 0.0;
		Command->setText("HOVERING");
		setLayout(grid);
	}
	else if(event->key() == Qt::Key_T)
	{	
	
		pubTakeoff1_.publish(msgTakeoff);
		Command->setText("TAKE OFF");
		setLayout(grid);
	
	}
	else if(event->key() == Qt::Key_Space)
	{	

		pubLand1_.publish(msgLand);
		Command->setText("LANDING");
		setLayout(grid);

	}
	else if(event->key() == Qt::Key_X)
	{	
		override.data = 6;
		OvR.publish(override);
		send_command = false;
		Command->setText("FORMATION");
		setLayout(grid);
		
	}
	else if(event->key() == Qt::Key_C)
	{	
		override.data = 10;
		OvR.publish(override);
		send_command = false;
		Command->setText("<font color=red>CANCEL CONTROLLER</font></h2>");
		setLayout(grid);

	}	
	else if(event->key() == Qt::Key_Q)
	{	
		yaw += speed;
		Command->setText("YAW LEFT");
		setLayout(grid);
	}
	else if(event->key() == Qt::Key_E)
	{	
		yaw -= speed;
		Command->setText("YAW RIGHT");
		setLayout(grid);
	}
	else if(event->key() == Qt::Key_W)
	{	
		pitch += speed;
		Command->setText("FORWARD");
		setLayout(grid);
	}
	else if(event->key() == Qt::Key_S)
	{	
		pitch -= speed;
		Command->setText("BACKWARD");
		setLayout(grid);
	}
	else if(event->key() == Qt::Key_A)
	{	
		roll += speed;
		Command->setText("LEFT");
		setLayout(grid);
	}
	else if(event->key() == Qt::Key_D)
	{	
		roll -= speed;
		Command->setText("RIGHT");
		setLayout(grid);
	}
	else if(event->key() == Qt::Key_Up)
	{	
		altitude += altitude_speed;
		Command->setText("UP");
		setLayout(grid);
	}
	else if(event->key() == Qt::Key_Down)
	{	
		altitude -= altitude_speed;
		Command->setText("DOWN");
		setLayout(grid);
	}
	else if(event->key() == Qt::Key_Left)
	{	
		speed -= .1;
		if(speed < .1) speed = .1;
		Speed_value->setText(QString::number(speed));		
		setLayout(grid);
	}
	else if(event->key() == Qt::Key_Right)
	{	
		speed += .1;
		if(speed > 1) speed = 1;
		Speed_value->setText(QString::number(speed));
		setLayout(grid);
	}
	else if(event->key() == Qt::Key_I)
	{	
		fovea_y += 5;
		if (fovea_y > 20) fovea_y = 20;
		Fovea_value_y->setText(QString::number(fovea_y));
		Command->setText("FOVEA UP");
		setLayout(grid);
	}
	else if(event->key() == Qt::Key_K)
	{	
		fovea_y -= 5;
		if (fovea_y < -85) fovea_y = -85;
		Fovea_value_y->setText(QString::number(fovea_y));
		Command->setText("FOVEA DOWN");
		setLayout(grid);
	}else if(event->key() == Qt::Key_1)//nuestros if
	{	
		//trajectoryPlanner(1);
		for(i=0; i<4; i++){
                pitch += 0.3;
				Command->setText("FORWARD");
				setLayout(grid)
                sleep_for(seconds(10));
                pitch = 0.0;
				roll = 0.0;
				altitude = 0.0;
				yaw = 0.0;
				Command->setText("HOVERING");
				setLayout(grid);
                sleep_for(seconds(1));
                yaw = 0.3;
				Command->setText("YAW: %d" speed);
				setLayout(grid);
                sleep_for(seconds(3));
                pitch = 0.0;
				roll = 0.0;
				altitude = 0.0;
				yaw = 0.0;
				Command->setText("HOVERING");
                sleep_for(seconds(1));
            }
	}else if(event->key() == Qt::Key_2)//nuestros if
	{	
		trajectoryPlanner(2);
	}else if(event->key() == Qt::Key_3)//nuestros if
	{	
		trajectoryPlanner(3);
	}else if(event->key() == Qt::Key_4)//nuestros if
	{	
		trajectoryPlanner(4);
	}	
	
	if(event->key() == Qt::Key_Escape)
	{
		qApp->quit();
	}
	
	commandPilot.linear.x = pitch;
	commandPilot.linear.y =  roll;
	commandPilot.linear.z = altitude;
	commandPilot.angular.z = yaw;
	
	commandCam.angular.y = fovea_y;
	
	pubCommandPilot1_.publish(commandPilot);
	pubCommandCamera1_.publish(commandCam);
	
}

//fucniones programadas por nosotros

 static void trajectoryPlanner(int a){
    //funciones a correr
    /*
    takeOff();
    Land();

    Hover();

    pitch(speed);
    yaw(speed);
    upDown(speed);
    pitchYaw(pitchSpeed,yawSpeed);

    */
    int i=0;
    switch(a){
		
        case 1://cuadrado
        
    i=0;
            for(i=0; i<4; i++){
                pitch(10);
                sleep_for(seconds(10));
                hover();
                sleep_for(seconds(1));
                yaw(3);
                sleep_for(seconds(3));
                hover();
                sleep_for(seconds(1));
            }
        break;
        case 2://cuadro sin esquinas
        i=0;
    
            for(i=0; i<4; i++){
                pitch(10);
                //5 seg
                pitchYaw(3, 8);
                //5 seg
            }
        break;
        case 3://hacer un 8
        
            //5 seg
            pitch(10);
            //5 seg
            pitchYaw(10, 10);
            //5 seg
            pitch(10);
            //5 seg
            pitchYaw(10, -10);
        break;
    }
}

    static void takeOff(){
        pubTakeoff1_.publish(msgTakeoff);
		Command->setText("TAKE OFF");
		setLayout(grid);
    }

    static void land(){
        pubLand1_.publish(msgLand);
		Command->setText("LANDING");
		setLayout(grid);
    }

    static void hover(){
        pitch = 0.0;
		roll = 0.0;
		altitude = 0.0;
		yaw = 0.0;
		Command->setText("HOVERING");
		setLayout(grid);
    }

    static void pitch(float speed){
        pitch = speed;
		Command->setText("FORWARD: %d" speed);
		setLayout(grid);
    }

    static void yaw(float speed){
        yaw = speed;
		Command->setText("YAW: %d" speed);
		setLayout(grid);
    }

    static void upDown(float speed){

    }

    static void pitchYaw(float speedP, float speedY){
        pitch = speedP;
        yaw = speedY;
		Command->setText("FORWARD YAW: %d %d" speedP, speedY);
		setLayout(grid);
    }
*/


