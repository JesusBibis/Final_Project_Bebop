## Documentation for bebop_autonomy

### View the documentation online

http://bebop-autonomy.readthedocs.org/

### Build documentation locally

Install [sphinx](http://sphinx-doc.org/latest/install.html) and [ReadTheDocs Theme](https://github.com/snide/sphinx_rtd_theme), then run `make`. 
